DROP DATABASE IF EXISTS news;

CREATE DATABASE news;

\c news

\i newsdata.sql

-- VIEWS :
-- viewcount: counts the views per article (Used in Questions 1 & 2)
CREATE VIEW viewcount AS
SELECT ar.author AS id, ar.title, l.counter
FROM articles AS ar LEFT JOIN (
    SELECT path, count(path) AS counter
    FROM log
    WHERE status LIKE '%200%'
GROUP BY log.path)
AS l
ON ar.slug = substring(l.path FROM 10);

-- log_404: tallies the logs and errors per each day. (Used in Question 3)
CREATE VIEW log_404 AS
SELECT date_trunc('day', time) AS date, count(*) AS logs, sum(CASE WHEN status='404 NOT FOUND' THEN 1 ELSE 0 END) AS errors
FROM log
GROUP BY date;


-- percentage: calculates the percentage of error per day. (Used in Question 3)
CREATE VIEW percentage AS
SELECT date, round( ((errors / logs::numeric) * 100), 2) AS error_percentage
FROM log_404
GROUP BY date, errors, logs
ORDER BY error_percentage DESC;
